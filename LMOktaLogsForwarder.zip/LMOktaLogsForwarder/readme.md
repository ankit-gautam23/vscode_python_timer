OKTA Log Integration with LM On Azure

[![Deploy to Azure](https://aka.ms/deploytoazurebutton)](https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fchoudharypooja%2Fvscode_python_timer%2Fmain%2Farm_template.json)

